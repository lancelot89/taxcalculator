from distutils.core import setup

setup(
    name='taxcalculator',
    version='1.0.0',
    packages=['roboter', 'roboter.models',
              'roboter.controller', 'roboter.views'],
    license='Free'
)
