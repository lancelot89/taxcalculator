from .. import test


# DEFAULT_ROBOT_NAME = 'Roboko'


# class Robot(object):
#     def __init__(self, name=DEFAULT_ROBOT_NAME, speak_color='green'):
#         self.neme = name
#         self.speak_color = speak_color

import sys

print(__file__)
