# import os
# import string

# import termcolor

# with open('C:/Users/izayo/Documents/work/taxcalculator/taxcalculator/templates/hello.txt', 'r', encoding='utf-8') as template_file:
#     color = None
#     contents = template_file.read()
#     contents = contents.rstrip(os.linesep)
#     contents = '{splitter}{sep}{contents}{sep}{splitter}{sep}'.format(
#         contents=contents, splitter="=" * 60, sep=os.linesep)
#     contents = termcolor.colored(contents, color)
#     t = string.Template(contents)
#     con = t.substitute(robot_name='Taka')
#     print(con)

import sys

print(__file__)
